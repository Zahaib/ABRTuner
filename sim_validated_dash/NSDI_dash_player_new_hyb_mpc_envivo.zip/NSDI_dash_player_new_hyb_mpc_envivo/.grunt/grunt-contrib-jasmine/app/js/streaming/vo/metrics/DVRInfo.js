
var __cov_LilSiSMCqEernNV_iI5E2g = (Function('return this'))();
if (!__cov_LilSiSMCqEernNV_iI5E2g.__coverage__) { __cov_LilSiSMCqEernNV_iI5E2g.__coverage__ = {}; }
__cov_LilSiSMCqEernNV_iI5E2g = __cov_LilSiSMCqEernNV_iI5E2g.__coverage__;
if (!(__cov_LilSiSMCqEernNV_iI5E2g['app/js/streaming/vo/metrics/DVRInfo.js'])) {
   __cov_LilSiSMCqEernNV_iI5E2g['app/js/streaming/vo/metrics/DVRInfo.js'] = {"path":"app/js/streaming/vo/metrics/DVRInfo.js","s":{"1":0,"2":0,"3":0,"4":0,"5":0},"b":{},"f":{"1":0},"fnMap":{"1":{"name":"(anonymous_1)","line":14,"loc":{"start":{"line":14,"column":33},"end":{"line":14,"column":45}}}},"statementMap":{"1":{"start":{"line":14,"column":0},"end":{"line":19,"column":2}},"2":{"start":{"line":16,"column":4},"end":{"line":16,"column":21}},"3":{"start":{"line":17,"column":4},"end":{"line":17,"column":22}},"4":{"start":{"line":18,"column":4},"end":{"line":18,"column":18}},"5":{"start":{"line":21,"column":0},"end":{"line":23,"column":2}}},"branchMap":{}};
}
__cov_LilSiSMCqEernNV_iI5E2g = __cov_LilSiSMCqEernNV_iI5E2g['app/js/streaming/vo/metrics/DVRInfo.js'];
__cov_LilSiSMCqEernNV_iI5E2g.s['1']++;MediaPlayer.vo.metrics.DVRInfo=function(){'use strict';__cov_LilSiSMCqEernNV_iI5E2g.f['1']++;__cov_LilSiSMCqEernNV_iI5E2g.s['2']++;this.time=null;__cov_LilSiSMCqEernNV_iI5E2g.s['3']++;this.range=null;__cov_LilSiSMCqEernNV_iI5E2g.s['4']++;this.mpd=null;};__cov_LilSiSMCqEernNV_iI5E2g.s['5']++;MediaPlayer.vo.metrics.DVRInfo.prototype={constructor:MediaPlayer.vo.metrics.DVRInfo};
