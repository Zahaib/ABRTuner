
var __cov_T_MaLzF0ZdbQzinSUKqhtw = (Function('return this'))();
if (!__cov_T_MaLzF0ZdbQzinSUKqhtw.__coverage__) { __cov_T_MaLzF0ZdbQzinSUKqhtw.__coverage__ = {}; }
__cov_T_MaLzF0ZdbQzinSUKqhtw = __cov_T_MaLzF0ZdbQzinSUKqhtw.__coverage__;
if (!(__cov_T_MaLzF0ZdbQzinSUKqhtw['app/js/dash/vo/AdaptationSet.js'])) {
   __cov_T_MaLzF0ZdbQzinSUKqhtw['app/js/dash/vo/AdaptationSet.js'] = {"path":"app/js/dash/vo/AdaptationSet.js","s":{"1":0,"2":0,"3":0,"4":0},"b":{},"f":{"1":0},"fnMap":{"1":{"name":"(anonymous_1)","line":14,"loc":{"start":{"line":14,"column":24},"end":{"line":14,"column":36}}}},"statementMap":{"1":{"start":{"line":14,"column":0},"end":{"line":18,"column":2}},"2":{"start":{"line":16,"column":4},"end":{"line":16,"column":23}},"3":{"start":{"line":17,"column":4},"end":{"line":17,"column":20}},"4":{"start":{"line":20,"column":0},"end":{"line":22,"column":2}}},"branchMap":{}};
}
__cov_T_MaLzF0ZdbQzinSUKqhtw = __cov_T_MaLzF0ZdbQzinSUKqhtw['app/js/dash/vo/AdaptationSet.js'];
__cov_T_MaLzF0ZdbQzinSUKqhtw.s['1']++;Dash.vo.AdaptationSet=function(){'use strict';__cov_T_MaLzF0ZdbQzinSUKqhtw.f['1']++;__cov_T_MaLzF0ZdbQzinSUKqhtw.s['2']++;this.period=null;__cov_T_MaLzF0ZdbQzinSUKqhtw.s['3']++;this.index=-1;};__cov_T_MaLzF0ZdbQzinSUKqhtw.s['4']++;Dash.vo.AdaptationSet.prototype={constructor:Dash.vo.AdaptationSet};
