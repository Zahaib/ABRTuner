
var __cov_w_dAghFngIY8s1QoKP6csw = (Function('return this'))();
if (!__cov_w_dAghFngIY8s1QoKP6csw.__coverage__) { __cov_w_dAghFngIY8s1QoKP6csw.__coverage__ = {}; }
__cov_w_dAghFngIY8s1QoKP6csw = __cov_w_dAghFngIY8s1QoKP6csw.__coverage__;
if (!(__cov_w_dAghFngIY8s1QoKP6csw['app/js/streaming/vo/metrics/DroppedFrames.js'])) {
   __cov_w_dAghFngIY8s1QoKP6csw['app/js/streaming/vo/metrics/DroppedFrames.js'] = {"path":"app/js/streaming/vo/metrics/DroppedFrames.js","s":{"1":0,"2":0,"3":0,"4":0},"b":{},"f":{"1":0},"fnMap":{"1":{"name":"(anonymous_1)","line":14,"loc":{"start":{"line":14,"column":39},"end":{"line":14,"column":51}}}},"statementMap":{"1":{"start":{"line":14,"column":0},"end":{"line":19,"column":2}},"2":{"start":{"line":17,"column":4},"end":{"line":17,"column":21}},"3":{"start":{"line":18,"column":4},"end":{"line":18,"column":30}},"4":{"start":{"line":21,"column":0},"end":{"line":23,"column":2}}},"branchMap":{}};
}
__cov_w_dAghFngIY8s1QoKP6csw = __cov_w_dAghFngIY8s1QoKP6csw['app/js/streaming/vo/metrics/DroppedFrames.js'];
__cov_w_dAghFngIY8s1QoKP6csw.s['1']++;MediaPlayer.vo.metrics.DroppedFrames=function(){'use strict';__cov_w_dAghFngIY8s1QoKP6csw.f['1']++;__cov_w_dAghFngIY8s1QoKP6csw.s['2']++;this.time=null;__cov_w_dAghFngIY8s1QoKP6csw.s['3']++;this.droppedFrames=null;};__cov_w_dAghFngIY8s1QoKP6csw.s['4']++;MediaPlayer.vo.metrics.DroppedFrames.prototype={constructor:MediaPlayer.vo.metrics.DroppedFrames};
