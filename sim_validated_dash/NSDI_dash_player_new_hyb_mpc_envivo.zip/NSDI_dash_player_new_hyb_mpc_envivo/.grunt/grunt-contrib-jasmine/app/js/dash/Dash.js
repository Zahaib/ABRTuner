
var __cov_p288eMwiJKkvfArnYER$Aw = (Function('return this'))();
if (!__cov_p288eMwiJKkvfArnYER$Aw.__coverage__) { __cov_p288eMwiJKkvfArnYER$Aw.__coverage__ = {}; }
__cov_p288eMwiJKkvfArnYER$Aw = __cov_p288eMwiJKkvfArnYER$Aw.__coverage__;
if (!(__cov_p288eMwiJKkvfArnYER$Aw['app/js/dash/Dash.js'])) {
   __cov_p288eMwiJKkvfArnYER$Aw['app/js/dash/Dash.js'] = {"path":"app/js/dash/Dash.js","s":{"1":0,"2":0},"b":{},"f":{"1":0},"fnMap":{"1":{"name":"(anonymous_1)","line":16,"loc":{"start":{"line":16,"column":8},"end":{"line":16,"column":20}}}},"statementMap":{"1":{"start":{"line":16,"column":0},"end":{"line":25,"column":5}},"2":{"start":{"line":19,"column":4},"end":{"line":24,"column":6}}},"branchMap":{}};
}
__cov_p288eMwiJKkvfArnYER$Aw = __cov_p288eMwiJKkvfArnYER$Aw['app/js/dash/Dash.js'];
__cov_p288eMwiJKkvfArnYER$Aw.s['1']++;Dash=function(){'use strict';__cov_p288eMwiJKkvfArnYER$Aw.f['1']++;__cov_p288eMwiJKkvfArnYER$Aw.s['2']++;return{modules:{},dependencies:{},vo:{},di:{}};}();
