
var __cov_NosEj$puJUA8HNMm5021qg = (Function('return this'))();
if (!__cov_NosEj$puJUA8HNMm5021qg.__coverage__) { __cov_NosEj$puJUA8HNMm5021qg.__coverage__ = {}; }
__cov_NosEj$puJUA8HNMm5021qg = __cov_NosEj$puJUA8HNMm5021qg.__coverage__;
if (!(__cov_NosEj$puJUA8HNMm5021qg['app/js/streaming/vo/MetricsList.js'])) {
   __cov_NosEj$puJUA8HNMm5021qg['app/js/streaming/vo/MetricsList.js'] = {"path":"app/js/streaming/vo/MetricsList.js","s":{"1":0,"2":0,"3":0},"b":{},"f":{"1":0},"fnMap":{"1":{"name":"(anonymous_1)","line":14,"loc":{"start":{"line":14,"column":33},"end":{"line":14,"column":45}}}},"statementMap":{"1":{"start":{"line":14,"column":0},"end":{"line":27,"column":2}},"2":{"start":{"line":17,"column":4},"end":{"line":26,"column":6}},"3":{"start":{"line":29,"column":0},"end":{"line":31,"column":2}}},"branchMap":{}};
}
__cov_NosEj$puJUA8HNMm5021qg = __cov_NosEj$puJUA8HNMm5021qg['app/js/streaming/vo/MetricsList.js'];
__cov_NosEj$puJUA8HNMm5021qg.s['1']++;MediaPlayer.models.MetricsList=function(){'use strict';__cov_NosEj$puJUA8HNMm5021qg.f['1']++;__cov_NosEj$puJUA8HNMm5021qg.s['2']++;return{TcpList:[],HttpList:[],RepSwitchList:[],BufferLevel:[],PlayList:[],DroppedFrames:[],DVRInfo:[],ManifestUpdate:[]};};__cov_NosEj$puJUA8HNMm5021qg.s['3']++;MediaPlayer.models.MetricsList.prototype={constructor:MediaPlayer.models.MetricsList};
