
var __cov_skFsXk22iI0VHtUJeNEINA = (Function('return this'))();
if (!__cov_skFsXk22iI0VHtUJeNEINA.__coverage__) { __cov_skFsXk22iI0VHtUJeNEINA.__coverage__ = {}; }
__cov_skFsXk22iI0VHtUJeNEINA = __cov_skFsXk22iI0VHtUJeNEINA.__coverage__;
if (!(__cov_skFsXk22iI0VHtUJeNEINA['app/js/streaming/vo/metrics/BufferLevel.js'])) {
   __cov_skFsXk22iI0VHtUJeNEINA['app/js/streaming/vo/metrics/BufferLevel.js'] = {"path":"app/js/streaming/vo/metrics/BufferLevel.js","s":{"1":0,"2":0,"3":0,"4":0},"b":{},"f":{"1":0},"fnMap":{"1":{"name":"(anonymous_1)","line":14,"loc":{"start":{"line":14,"column":37},"end":{"line":14,"column":49}}}},"statementMap":{"1":{"start":{"line":14,"column":0},"end":{"line":19,"column":2}},"2":{"start":{"line":17,"column":4},"end":{"line":17,"column":18}},"3":{"start":{"line":18,"column":4},"end":{"line":18,"column":22}},"4":{"start":{"line":21,"column":0},"end":{"line":23,"column":2}}},"branchMap":{}};
}
__cov_skFsXk22iI0VHtUJeNEINA = __cov_skFsXk22iI0VHtUJeNEINA['app/js/streaming/vo/metrics/BufferLevel.js'];
__cov_skFsXk22iI0VHtUJeNEINA.s['1']++;MediaPlayer.vo.metrics.BufferLevel=function(){'use strict';__cov_skFsXk22iI0VHtUJeNEINA.f['1']++;__cov_skFsXk22iI0VHtUJeNEINA.s['2']++;this.t=null;__cov_skFsXk22iI0VHtUJeNEINA.s['3']++;this.level=null;};__cov_skFsXk22iI0VHtUJeNEINA.s['4']++;MediaPlayer.vo.metrics.BufferLevel.prototype={constructor:MediaPlayer.vo.metrics.BufferLevel};
