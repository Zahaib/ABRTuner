
var __cov__efHH0H9yciFRpzBU$m1$A = (Function('return this'))();
if (!__cov__efHH0H9yciFRpzBU$m1$A.__coverage__) { __cov__efHH0H9yciFRpzBU$m1$A.__coverage__ = {}; }
__cov__efHH0H9yciFRpzBU$m1$A = __cov__efHH0H9yciFRpzBU$m1$A.__coverage__;
if (!(__cov__efHH0H9yciFRpzBU$m1$A['app/js/streaming/algo/FastMPC.js'])) {
   __cov__efHH0H9yciFRpzBU$m1$A['app/js/streaming/algo/FastMPC.js'] = {"path":"app/js/streaming/algo/FastMPC.js","s":{"1":0,"2":0,"3":0,"4":0},"b":{},"f":{"1":0,"2":0},"fnMap":{"1":{"name":"(anonymous_1)","line":1,"loc":{"start":{"line":1,"column":35},"end":{"line":1,"column":47}}},"2":{"name":"(anonymous_2)","line":10,"loc":{"start":{"line":10,"column":13},"end":{"line":10,"column":25}}}},"statementMap":{"1":{"start":{"line":1,"column":0},"end":{"line":14,"column":2}},"2":{"start":{"line":4,"column":0},"end":{"line":13,"column":6}},"3":{"start":{"line":11,"column":12},"end":{"line":11,"column":21}},"4":{"start":{"line":16,"column":0},"end":{"line":18,"column":2}}},"branchMap":{}};
}
__cov__efHH0H9yciFRpzBU$m1$A = __cov__efHH0H9yciFRpzBU$m1$A['app/js/streaming/algo/FastMPC.js'];
__cov__efHH0H9yciFRpzBU$m1$A.s['1']++;MediaPlayer.dependencies.FastMPC=function(){'use strict';__cov__efHH0H9yciFRpzBU$m1$A.f['1']++;__cov__efHH0H9yciFRpzBU$m1$A.s['2']++;return{debug:undefined,abrRulesCollection:undefined,manifestExt:undefined,metricsModel:undefined,getBitrate:function(){__cov__efHH0H9yciFRpzBU$m1$A.f['2']++;__cov__efHH0H9yciFRpzBU$m1$A.s['3']++;return 0;}};};__cov__efHH0H9yciFRpzBU$m1$A.s['4']++;MediaPlayer.dependencies.FastMPC.prototype={constructor:MediaPlayer.dependencies.FastMPC};
