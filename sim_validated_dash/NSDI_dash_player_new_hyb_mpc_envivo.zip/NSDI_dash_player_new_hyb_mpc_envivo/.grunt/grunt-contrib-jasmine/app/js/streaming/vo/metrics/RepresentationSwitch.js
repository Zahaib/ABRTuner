
var __cov_8kIN7RXbC9_bK_7GWRmhBA = (Function('return this'))();
if (!__cov_8kIN7RXbC9_bK_7GWRmhBA.__coverage__) { __cov_8kIN7RXbC9_bK_7GWRmhBA.__coverage__ = {}; }
__cov_8kIN7RXbC9_bK_7GWRmhBA = __cov_8kIN7RXbC9_bK_7GWRmhBA.__coverage__;
if (!(__cov_8kIN7RXbC9_bK_7GWRmhBA['app/js/streaming/vo/metrics/RepresentationSwitch.js'])) {
   __cov_8kIN7RXbC9_bK_7GWRmhBA['app/js/streaming/vo/metrics/RepresentationSwitch.js'] = {"path":"app/js/streaming/vo/metrics/RepresentationSwitch.js","s":{"1":0,"2":0,"3":0,"4":0,"5":0,"6":0},"b":{},"f":{"1":0},"fnMap":{"1":{"name":"(anonymous_1)","line":14,"loc":{"start":{"line":14,"column":46},"end":{"line":14,"column":58}}}},"statementMap":{"1":{"start":{"line":14,"column":0},"end":{"line":21,"column":2}},"2":{"start":{"line":17,"column":4},"end":{"line":17,"column":18}},"3":{"start":{"line":18,"column":4},"end":{"line":18,"column":19}},"4":{"start":{"line":19,"column":4},"end":{"line":19,"column":19}},"5":{"start":{"line":20,"column":4},"end":{"line":20,"column":20}},"6":{"start":{"line":23,"column":0},"end":{"line":25,"column":2}}},"branchMap":{}};
}
__cov_8kIN7RXbC9_bK_7GWRmhBA = __cov_8kIN7RXbC9_bK_7GWRmhBA['app/js/streaming/vo/metrics/RepresentationSwitch.js'];
__cov_8kIN7RXbC9_bK_7GWRmhBA.s['1']++;MediaPlayer.vo.metrics.RepresentationSwitch=function(){'use strict';__cov_8kIN7RXbC9_bK_7GWRmhBA.f['1']++;__cov_8kIN7RXbC9_bK_7GWRmhBA.s['2']++;this.t=null;__cov_8kIN7RXbC9_bK_7GWRmhBA.s['3']++;this.mt=null;__cov_8kIN7RXbC9_bK_7GWRmhBA.s['4']++;this.to=null;__cov_8kIN7RXbC9_bK_7GWRmhBA.s['5']++;this.lto=null;};__cov_8kIN7RXbC9_bK_7GWRmhBA.s['6']++;MediaPlayer.vo.metrics.RepresentationSwitch.prototype={constructor:MediaPlayer.vo.metrics.RepresentationSwitch};
