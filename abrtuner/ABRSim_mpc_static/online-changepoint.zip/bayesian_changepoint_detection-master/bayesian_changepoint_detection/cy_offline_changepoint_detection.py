import pyximport
pyximport.install()
from cy_offline import *


