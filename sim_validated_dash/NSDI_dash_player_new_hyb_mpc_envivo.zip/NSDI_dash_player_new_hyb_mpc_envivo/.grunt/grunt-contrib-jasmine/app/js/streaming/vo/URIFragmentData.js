
var __cov_t56uGS8gRlLlx3kkifcprQ = (Function('return this'))();
if (!__cov_t56uGS8gRlLlx3kkifcprQ.__coverage__) { __cov_t56uGS8gRlLlx3kkifcprQ.__coverage__ = {}; }
__cov_t56uGS8gRlLlx3kkifcprQ = __cov_t56uGS8gRlLlx3kkifcprQ.__coverage__;
if (!(__cov_t56uGS8gRlLlx3kkifcprQ['app/js/streaming/vo/URIFragmentData.js'])) {
   __cov_t56uGS8gRlLlx3kkifcprQ['app/js/streaming/vo/URIFragmentData.js'] = {"path":"app/js/streaming/vo/URIFragmentData.js","s":{"1":0,"2":0,"3":0,"4":0,"5":0,"6":0,"7":0},"b":{},"f":{"1":0},"fnMap":{"1":{"name":"(anonymous_1)","line":14,"loc":{"start":{"line":14,"column":33},"end":{"line":14,"column":45}}}},"statementMap":{"1":{"start":{"line":14,"column":0},"end":{"line":21,"column":2}},"2":{"start":{"line":16,"column":4},"end":{"line":16,"column":18}},"3":{"start":{"line":17,"column":4},"end":{"line":17,"column":21}},"4":{"start":{"line":18,"column":4},"end":{"line":18,"column":22}},"5":{"start":{"line":19,"column":4},"end":{"line":19,"column":19}},"6":{"start":{"line":20,"column":4},"end":{"line":20,"column":18}},"7":{"start":{"line":23,"column":0},"end":{"line":25,"column":2}}},"branchMap":{}};
}
__cov_t56uGS8gRlLlx3kkifcprQ = __cov_t56uGS8gRlLlx3kkifcprQ['app/js/streaming/vo/URIFragmentData.js'];
__cov_t56uGS8gRlLlx3kkifcprQ.s['1']++;MediaPlayer.vo.URIFragmentData=function(){'use strict';__cov_t56uGS8gRlLlx3kkifcprQ.f['1']++;__cov_t56uGS8gRlLlx3kkifcprQ.s['2']++;this.t=null;__cov_t56uGS8gRlLlx3kkifcprQ.s['3']++;this.xywh=null;__cov_t56uGS8gRlLlx3kkifcprQ.s['4']++;this.track=null;__cov_t56uGS8gRlLlx3kkifcprQ.s['5']++;this.id=null;__cov_t56uGS8gRlLlx3kkifcprQ.s['6']++;this.s=null;};__cov_t56uGS8gRlLlx3kkifcprQ.s['7']++;MediaPlayer.vo.URIFragmentData.prototype={constructor:MediaPlayer.vo.URIFragmentData};
