
var __cov_FYYS$8dr1dgYhI$_IX$xTQ = (Function('return this'))();
if (!__cov_FYYS$8dr1dgYhI$_IX$xTQ.__coverage__) { __cov_FYYS$8dr1dgYhI$_IX$xTQ.__coverage__ = {}; }
__cov_FYYS$8dr1dgYhI$_IX$xTQ = __cov_FYYS$8dr1dgYhI$_IX$xTQ.__coverage__;
if (!(__cov_FYYS$8dr1dgYhI$_IX$xTQ['app/js/streaming/algo/BandwidthPredictor.js'])) {
   __cov_FYYS$8dr1dgYhI$_IX$xTQ['app/js/streaming/algo/BandwidthPredictor.js'] = {"path":"app/js/streaming/algo/BandwidthPredictor.js","s":{"1":0,"2":0,"3":0,"4":0},"b":{},"f":{"1":0,"2":0},"fnMap":{"1":{"name":"(anonymous_1)","line":1,"loc":{"start":{"line":1,"column":46},"end":{"line":1,"column":58}}},"2":{"name":"(anonymous_2)","line":10,"loc":{"start":{"line":10,"column":13},"end":{"line":10,"column":25}}}},"statementMap":{"1":{"start":{"line":1,"column":0},"end":{"line":14,"column":2}},"2":{"start":{"line":4,"column":0},"end":{"line":13,"column":6}},"3":{"start":{"line":11,"column":12},"end":{"line":11,"column":21}},"4":{"start":{"line":16,"column":0},"end":{"line":18,"column":2}}},"branchMap":{}};
}
__cov_FYYS$8dr1dgYhI$_IX$xTQ = __cov_FYYS$8dr1dgYhI$_IX$xTQ['app/js/streaming/algo/BandwidthPredictor.js'];
__cov_FYYS$8dr1dgYhI$_IX$xTQ.s['1']++;MediaPlayer.dependencies.BandwidthPredictor=function(){'use strict';__cov_FYYS$8dr1dgYhI$_IX$xTQ.f['1']++;__cov_FYYS$8dr1dgYhI$_IX$xTQ.s['2']++;return{debug:undefined,abrRulesCollection:undefined,manifestExt:undefined,metricsModel:undefined,getBitrate:function(){__cov_FYYS$8dr1dgYhI$_IX$xTQ.f['2']++;__cov_FYYS$8dr1dgYhI$_IX$xTQ.s['3']++;return 0;}};};__cov_FYYS$8dr1dgYhI$_IX$xTQ.s['4']++;MediaPlayer.dependencies.BandwidthPredictor.prototype={constructor:MediaPlayer.dependencies.BandwidthPredictor};
